package com.example.tarea1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FibonacciActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fibonacci);
    }
}